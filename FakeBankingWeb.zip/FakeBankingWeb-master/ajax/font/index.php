<?php
header('Location: ../../');
exit;
?>
